// SCORM 1.2 API wrapper — auto-completes course on finish
(function(){
  var API = null;
  var _initialized = false;
  var _completed = false;

  function findAPI(win){
    var attempts = 0;
    while(win.API == null && win.parent != null && win.parent != win){
      attempts++;
      if(attempts > 7) return null;
      win = win.parent;
    }
    return win.API || null;
  }

  function getAPI(){
    if(API) return API;
    API = findAPI(window);
    if(!API && window.opener) API = findAPI(window.opener);
    return API;
  }

  window.SCORM = {
    init: function(){
      var api = getAPI();
      if(!api) return false;
      var result = api.LMSInitialize('');
      if(result === 'true' || result === true){
        _initialized = true;
        api.LMSSetValue('cmi.core.lesson_status', 'incomplete');
        api.LMSCommit('');
      }
      return _initialized;
    },
    complete: function(){
      if(_completed) return;
      var api = getAPI();
      if(!api || !_initialized) return;
      api.LMSSetValue('cmi.core.lesson_status', 'passed');
      api.LMSSetValue('cmi.core.score.raw', '100');
      api.LMSSetValue('cmi.core.score.min', '0');
      api.LMSSetValue('cmi.core.score.max', '100');
      api.LMSCommit('');
      _completed = true;
    },
    finish: function(){
      var api = getAPI();
      if(!api || !_initialized) return;
      this.complete();
      api.LMSFinish('');
    }
  };

  window.addEventListener('load', function(){ window.SCORM.init(); });
  window.addEventListener('beforeunload', function(){ window.SCORM.finish(); });
})();
